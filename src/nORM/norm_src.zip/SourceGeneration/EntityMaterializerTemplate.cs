namespace nORM.SourceGeneration;

/// <summary>
/// Placeholder template class for entity materializer source generation.
/// </summary>
public static class EntityMaterializerTemplate
{
    // Intentionally left blank. This type exists to anchor generated materializers.
}
