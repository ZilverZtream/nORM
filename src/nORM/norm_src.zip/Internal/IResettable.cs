namespace nORM.Internal;

internal interface IResettable
{
    void Reset();
}
