using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

namespace nORM.Core
{
    /// <summary>
    /// High-performance extension methods for nORM async operations
    /// These are specifically designed for nORM queries to avoid conflicts with other ORMs
    /// </summary>
    public static class NormAsyncExtensions
    {
        /// <summary>
        /// Streams nORM query results asynchronously - only works with nORM queries
        /// </summary>
        public static IAsyncEnumerable<T> AsAsyncEnumerable<T>(this IQueryable<T> source, CancellationToken ct = default)
            where T : class
        {
            if (source.Provider is Query.NormQueryProvider normProvider)
            {
                return normProvider.AsAsyncEnumerable<T>(source.Expression, ct);
            }

            throw new NormUsageException(
                "AsAsyncEnumerable extension can only be used with nORM queries. " +
                "Make sure you started with context.Query<T>().");
        }

        /// <summary>
        /// Converts nORM query to List asynchronously - only works with nORM queries
        /// </summary>
        public static Task<List<T>> ToListAsync<T>(this IQueryable<T> source, CancellationToken ct = default)
            where T : class
        {
            // Only works with nORM provider - this avoids conflicts with EF Core
            if (source.Provider is Query.NormQueryProvider normProvider)
            {
                return normProvider.ExecuteAsync<List<T>>(source.Expression, ct);
            }
            
            throw new NormUsageException(
                "ToListAsync extension can only be used with nORM queries. " +
                "Make sure you started with context.Query<T>(). " +
                "For Entity Framework queries, use Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToListAsync().");
        }

        /// <summary>
        /// Counts nORM query results asynchronously - only works with nORM queries
        /// </summary>
        public static Task<int> CountAsync<T>(this IQueryable<T> source, CancellationToken ct = default)
            where T : class
        {
            if (source.Provider is Query.NormQueryProvider normProvider)
            {
                var countExpression = Expression.Call(
                    typeof(Queryable), 
                    nameof(Queryable.Count), 
                    new[] { typeof(T) }, 
                    source.Expression);
                return normProvider.ExecuteAsync<int>(countExpression, ct);
            }
            
            throw new NormUsageException(
                "CountAsync extension can only be used with nORM queries. " +
                "Make sure you started with context.Query<T>(). " +
                "For Entity Framework queries, use Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.CountAsync().");
        }

        /// <summary>
        /// Converts nORM query to List synchronously - only works with nORM queries
        /// </summary>
        public static List<T> ToListSync<T>(this IQueryable<T> source) where T : class
        {
            if (source.Provider is Query.NormQueryProvider normProvider)
            {
                return normProvider.ExecuteSync<List<T>>(source.Expression);
            }

            throw new NormUsageException("ToListSync can only be used with nORM queries.");
        }

        /// <summary>
        /// Counts nORM query results synchronously - only works with nORM queries
        /// </summary>
        public static int CountSync<T>(this IQueryable<T> source) where T : class
        {
            if (source.Provider is Query.NormQueryProvider normProvider)
            {
                var countExpression = Expression.Call(
                    typeof(Queryable),
                    nameof(Queryable.Count),
                    new[] { typeof(T) },
                    source.Expression);
                return normProvider.ExecuteSync<int>(countExpression);
            }

            throw new NormUsageException("CountSync can only be used with nORM queries.");
        }

        /// <summary>
        /// Converts nORM query to Array asynchronously - only works with nORM queries  
        /// </summary>
        public static async Task<T[]> ToArrayAsync<T>(this IQueryable<T> source, CancellationToken ct = default)
            where T : class
        {
            if (source.Provider is Query.NormQueryProvider)
            {
                var list = await source.ToListAsync(ct).ConfigureAwait(false);
                return list.ToArray();
            }
            
            throw new NormUsageException(
                "ToArrayAsync extension can only be used with nORM queries. " +
                "Make sure you started with context.Query<T>(). " +
                "For Entity Framework queries, use Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.ToArrayAsync().");
        }

        /// <summary>
        /// Checks if nORM query has any results asynchronously - only works with nORM queries
        /// </summary>
        public static async Task<bool> AnyAsync<T>(this IQueryable<T> source, CancellationToken ct = default)
            where T : class
        {
            if (source.Provider is Query.NormQueryProvider normProvider)
            {
                var anyExpression = Expression.Call(
                    typeof(Queryable),
                    nameof(Queryable.Any),
                    new[] { typeof(T) },
                    source.Expression);
                return await normProvider.ExecuteAsync<bool>(anyExpression, ct).ConfigureAwait(false);
            }
            
            throw new NormUsageException(
                "AnyAsync extension can only be used with nORM queries. " +
                "Make sure you started with context.Query<T>(). " +
                "For Entity Framework queries, use Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.AnyAsync().");
        }

        /// <summary>
        /// Gets first result from nORM query asynchronously - only works with nORM queries
        /// </summary>
        public static Task<T> FirstAsync<T>(this IQueryable<T> source, CancellationToken ct = default)
            where T : class
        {
            if (source.Provider is Query.NormQueryProvider normProvider)
            {
                var firstExpression = Expression.Call(
                    typeof(Queryable), 
                    nameof(Queryable.First), 
                    new[] { typeof(T) }, 
                    source.Expression);
                return normProvider.ExecuteAsync<T>(firstExpression, ct);
            }
            
            throw new NormUsageException(
                "FirstAsync extension can only be used with nORM queries. " +
                "Make sure you started with context.Query<T>(). " +
                "For Entity Framework queries, use Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.FirstAsync().");
        }

        /// <summary>
        /// Gets first result or default from nORM query asynchronously - only works with nORM queries
        /// </summary>
        public static Task<T?> FirstOrDefaultAsync<T>(this IQueryable<T> source, CancellationToken ct = default)
            where T : class
        {
            if (source.Provider is Query.NormQueryProvider normProvider)
            {
                var firstOrDefaultExpression = Expression.Call(
                    typeof(Queryable),
                    nameof(Queryable.FirstOrDefault),
                    new[] { typeof(T) },
                    source.Expression);
                return normProvider.ExecuteAsync<T?>(firstOrDefaultExpression, ct);
            }

            throw new NormUsageException(
                "FirstOrDefaultAsync extension can only be used with nORM queries. " +
                "Make sure you started with context.Query<T>(). " +
                "For Entity Framework queries, use Microsoft.EntityFrameworkCore.EntityFrameworkQueryableExtensions.FirstOrDefaultAsync().");
        }

        public static Task<int> ExecuteDeleteAsync<T>(this IQueryable<T> source, CancellationToken ct = default)
            where T : class
        {
            if (source.Provider is Query.NormQueryProvider normProvider)
            {
                return normProvider.ExecuteDeleteAsync(source.Expression, ct);
            }

            throw new NormUsageException(
                "ExecuteDeleteAsync extension can only be used with nORM queries. " +
                "Make sure you started with context.Query<T>().");
        }

        public static Task<int> ExecuteUpdateAsync<T>(this IQueryable<T> source, Expression<Func<SetPropertyCalls<T>, SetPropertyCalls<T>>> set, CancellationToken ct = default)
            where T : class
        {
            if (source.Provider is Query.NormQueryProvider normProvider)
            {
                return normProvider.ExecuteUpdateAsync(source.Expression, set, ct);
            }

            throw new NormUsageException(
                "ExecuteUpdateAsync extension can only be used with nORM queries. " +
                "Make sure you started with context.Query<T>().");
        }
        
        // Join operations for nORM - these don't conflict since they return IQueryable
        public static IQueryable<TResult> Join<TOuter, TInner, TKey, TResult>(
            this IQueryable<TOuter> outer,
            IQueryable<TInner> inner,
            Expression<Func<TOuter, TKey>> outerKeySelector,
            Expression<Func<TInner, TKey>> innerKeySelector,
            Expression<Func<TOuter, TInner, TResult>> resultSelector)
        {
            return Queryable.Join(outer, inner, outerKeySelector, innerKeySelector, resultSelector);
        }
        
        public static IQueryable<TResult> GroupJoin<TOuter, TInner, TKey, TResult>(
            this IQueryable<TOuter> outer,
            IQueryable<TInner> inner,
            Expression<Func<TOuter, TKey>> outerKeySelector,
            Expression<Func<TInner, TKey>> innerKeySelector,
            Expression<Func<TOuter, IEnumerable<TInner>, TResult>> resultSelector)
        {
            return Queryable.GroupJoin(outer, inner, outerKeySelector, innerKeySelector, resultSelector);
        }
    }
}
