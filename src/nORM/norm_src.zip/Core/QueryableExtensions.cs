// This file was removed - extensions are not needed since
// nORM's QueryProvider now properly returns INormQueryable<T> instances
// which have the async methods built-in.
