namespace nORM.Core
{
    public enum QueryTrackingBehavior
    {
        TrackAll,
        NoTracking
    }
}
