using System;

namespace nORM.Mapping
{
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class OwnedAttribute : Attribute
    {
    }
}
